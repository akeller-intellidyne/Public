$csvfile = Import-csv ".\LogFile.csv"

$mrc = "40RG05N"

$n = 0

$csvfile |foreach{if(($_.MRC -eq $mrc) -and ($_.Status -eq "Pending")){
	$n += 1
    $_.Status = "Running"
    $_.Initiated = [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')}}

if($n -eq 0){
    $newRow = New-Object PsObject -Property @{ MRC = $mrc ; Initiated = [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ') ; Status='Running'}
    
    $csvfile += $newRow}


$csvfile |Export-Csv -NoTypeInformation -Path ".\LogFile.csv"

Write-Host 'Passwords have not expired'