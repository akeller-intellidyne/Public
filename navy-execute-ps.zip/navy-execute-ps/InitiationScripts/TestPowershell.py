#Needs to be in same folder as ps1 scripts or else relative reference "./etc" will call based on the location of python not ps1

import subprocess
import os
import sys

def run(cmd):
    completed = subprocess.run(["powershell", "-Command", cmd], capture_output=True)
    return completed

if __name__ == '__main__':
    local_syntax_info = run("./Initiate2311.ps1")
    if local_syntax_info.returncode != 0:
        print("An error occured: %s", local_syntax_info.stderr)
    else:
        print("New command executed successfully!", local_syntax_info.stdout)