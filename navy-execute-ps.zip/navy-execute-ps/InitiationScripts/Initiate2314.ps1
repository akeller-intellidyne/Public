$csvfile = Import-csv ".\LogFile.csv"

$mrc = "2314"

$newRow = New-Object PsObject -Property @{ MRC = $mrc ; Initiated = [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ') ; Completed = [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ') ; Status='Failed'}

$csvfile += $newRow

$csvfile |Export-Csv -NoTypeInformation -Path ".\LogFile.csv"

Write-Host 'Windows unable to detect necessary caffeination level in sailors'