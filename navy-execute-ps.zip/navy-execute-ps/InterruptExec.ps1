$csvfile = Import-csv ".\LogFile.csv"

#count of changed records
$n = 0 

if($args){$mrc=$args[0]}

$csvfile |foreach{if(($_.MRC -eq $mrc) -and ($_.Status -eq "In Progress")){
	$n += 1
    $_.Status = "Interrupted"
    $_.Completed = [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ')}}

if($n -ge 1){
	$csvfile |Export-Csv -NoTypeInformation -Path .\LogFile.csv
	Write-Output $mrc "Interrupted"}
	else{
		Write-Output $mrc "Not Currently In Process"} 